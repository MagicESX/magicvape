fx_version 'cerulean'
game 'gta5'

name 'magicvape'
author 'MagicESX.com#2937'
description 'Standalone Vaping Resource'
version '1.14'
client_scripts{
	'Config.lua',
	'cl-vape.lua'
}

server_scripts{
	'Config.lua',
	'sv-vape.lua'
}